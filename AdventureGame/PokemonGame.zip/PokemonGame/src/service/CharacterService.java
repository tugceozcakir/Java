package service;

import model.Ash;
import model.Character;
import model.SpecialPower;

public class CharacterService {

}
