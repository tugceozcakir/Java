package model;

public class Electricty extends SpecialPower{
    public Electricty(String name, int extraDamage, int remainingRights) {
        super(name, extraDamage, remainingRights);
    }
}
