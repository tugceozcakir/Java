package model;

public class Water extends SpecialPower {
    public Water(String name, int extraDamage, int remainingRights) {
        super(name, extraDamage, remainingRights);
    }
}
