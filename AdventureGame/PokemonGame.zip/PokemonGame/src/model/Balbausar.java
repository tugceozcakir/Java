package model;

public class Balbausar extends Pokemon{
    public Balbausar(String name, int health, int damage, TypeEnum type, SpecialPower specialPower) {
        super(name, health, damage, type, specialPower);
    }
}
