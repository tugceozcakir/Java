package model;

public class Strategy extends SpecialPower{
    public Strategy(String name, int extraDamage, int remainingRights) {
        super(name, extraDamage, remainingRights);
    }
}
