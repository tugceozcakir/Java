package model;

public enum TypeEnum {
    FIRE, WATER, GRASS, ELECTRICY, WING, EARTH;


}
