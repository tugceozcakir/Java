package model;

public class Fire extends SpecialPower{
    public Fire(String name, int extraDamage, int remainingRights) {
        super(name, extraDamage, remainingRights);
    }
}
