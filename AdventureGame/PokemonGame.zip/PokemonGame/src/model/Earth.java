package model;

public class Earth extends SpecialPower{
    public Earth(String name, int extraDamage, int remainingRights) {
        super(name, extraDamage, remainingRights);
    }
}
